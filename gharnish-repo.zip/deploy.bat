@echo off
cd /d "%~dp0"
echo ============================================
echo   GHARNISH DEPLOY  -  worker: gharnish-app
echo ============================================
call npx --yes wrangler@latest deploy
echo.
echo Done. Verify the BUILD badge at gharnish.app/admin.html
pause
