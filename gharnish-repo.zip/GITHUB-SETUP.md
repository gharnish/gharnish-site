# Gharnish — Cloud Deploy Setup (works from any system, browser only)

## One-time setup (~15 minutes)

### 1. Create the repo
- github.com -> New repository -> name: `gharnish-site` -> **Private** -> Create.

### 2. Upload this bundle (no git tools needed)
- On the empty repo page click "uploading an existing file".
- Drag in: `worker.js`, `wrangler.jsonc`, and the entire `site/` folder
  (Chrome/Edge support dragging whole folders).
- Commit changes.

### 3. Connect Cloudflare auto-deploy
- Cloudflare Dashboard -> Workers & Pages -> **gharnish-app** -> Settings -> **Builds**
- Connect to Git -> authorize GitHub -> select `gharnish-site`
- Build command: (leave empty)   Deploy command: `npx wrangler deploy`
- Save. Cloudflare now deploys automatically on every commit.

## Daily workflow — from ANY computer, browser only
1. Get the updated file(s) from Claude (usually just `admin.html`, `manager.html`, or `index.html`).
2. Repo -> `site/` folder -> Add file -> Upload files -> drag them in -> Commit.
3. Cloudflare auto-deploys in about a minute. Verify the BUILD badge.

## Bonus you get for free
- **Version history & one-click rollback** for every build (repo commits).
- All your systems always in sync — the repo is the single source of truth.
- Ready for Claude Code on the web (claude.com/code): connect this repo there
  and you can request changes from any device; it edits, commits and opens a
  PR — merge = live.
