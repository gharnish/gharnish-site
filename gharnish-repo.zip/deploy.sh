#!/usr/bin/env bash
cd "$(dirname "$0")"
npx --yes wrangler@latest deploy
